<template>
  <v-container
    class="fill-height"
    fluid
    style="min-height: 434px">
    <v-fade-transition mode="out-in">
      <v-row>
        <v-col
          class="d-flex child-flex"
          cols="4"
          v-for="(personaje, index) in personajes" :key="index" img-alt='personaje.nombre'>
          <v-card>
            <v-img
              :src="`https://rickandmortyapi.com/api/character/avatar/${index + 1}.jpeg`"></v-img>
            <v-card-title class="text-h4"> {{personaje.id}}. {{personaje.nombre}} </v-card-title>
          </v-card>
        </v-col>
      </v-row>
    </v-fade-transition>
  </v-container>
</template>

<script>
export default {
  name: 'IndexPage',
  data() {
    return {
        personajes: [{
            id: 1,
            nombre: "Rick",
//            imagen: "https://rickandmortyapi.com/api/character/avatar/1.jpeg"
        },
        {
            id: 2,
            nombre: "Morty",
//            imagen: "https://rickandmortyapi.com/api/character/avatar/2.jpeg"
        },
        {
            id: 3,
            nombre: "Summer",
//            imagen: "https://rickandmortyapi.com/api/character/avatar/3.jpeg"
        },
        {
            id: 4,
            nombre: "Beth",
//            imagen: "https://rickandmortyapi.com/api/character/avatar/4.jpeg"
        },
        {
            id: 5,
            nombre: "Jerry",
//            imagen: "https://rickandmortyapi.com/api/character/avatar/5.jpeg"
        }
        ]
    }
  },
}
</script>
